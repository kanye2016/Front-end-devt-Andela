// Select color input
// Select size input

// When size is submitted by the user, call makeGrid()
$('#sizePicker').submit(function (grid) {
			grid.preventDefault(); //// Enable the grid to stay for long when submit button is clicked
			var setHeight = $('#inputHeight').val();
			var setWeight = $('#inputWeight').val();
				///Function call
				makeGrid(setHeight, setWeight);
			
	});



	function makeGrid(rows, cols) {

		$('tr').remove(); //Remove any table row if present.
	// Your code goes here!

		for (var i = 1; i <= rows; i++) {
				$('#pixelCanvas').append('<tr id=table' + i  + '></tr>');

				for (var j = 1; j <= cols; j++) {
					$('tr:last').append('<td></td>');

					////Class for each td.  and add an atribute
					$('td').attr('class', 'cells');
				}
		}
				

				///Class cells on each td and having click envent
				$('.cells').click(function(event) {
					var paint = $('#colorPicker').val();
					$(event.target).css('background-color',paint)
				});
	}



